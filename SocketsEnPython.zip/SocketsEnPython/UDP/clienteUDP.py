import socket

HOST = "127.0.0.1"
PORT = 5055

cliente = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

mensaje = "El cliente UDP les manda saludos"

cliente.sendto(mensaje.encode(), (HOST, PORT))
print("Mensaje enviado al servidor.")

respuesta, direccion_servidor = cliente.recvfrom(1024)
print(f"Respuesta del servidor: {respuesta.decode()}")

# Cerrar socket
cliente.close()
print("Cliente UDP cerrado.")