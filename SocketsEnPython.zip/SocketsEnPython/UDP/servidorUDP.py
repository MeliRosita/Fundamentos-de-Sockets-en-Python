import socket

HOST = "0.0.0.0"
PORT = 5055

servidor = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

servidor.bind((HOST, PORT))

print(f"Servidor UDP escuchando en {HOST}:{PORT}...")

mensaje, direccion_cliente = servidor.recvfrom(1024)
print(f"Mensaje recibido de {direccion_cliente}: {mensaje.decode()}")

respuesta = "El servidor UDP les manda saludos"
servidor.sendto(respuesta.encode(), direccion_cliente)

print("Respuesta enviada al cliente.")

servidor.close()
print("Servidor UDP cerrado.")